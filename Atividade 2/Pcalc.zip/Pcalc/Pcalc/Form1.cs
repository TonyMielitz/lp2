﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        Double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            txtresultado.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saida",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtresultado.Text = (numero1 + numero2).ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txtresultado.Text = (numero1 - numero2).ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            txtresultado.Text = (numero1 * numero2).ToString();
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(textBox2.Text, out numero2))
            {
                errorProvider2.SetError(textBox2, "Numero 2 Inválido");
                textBox1.Focus();
            }
            else
            {
                errorProvider2.SetError(textBox2, "");
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (numero2 != 0)
            {
                txtresultado.Text = (numero1 / numero2).ToString();
            }
            else
            {
                MessageBox.Show("impossivel dividir por zero");
            }
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(textBox1.Text, out numero1))
            {
                errorProvider1.SetError(textBox1, "Numero 1 Inválido");
                textBox1.Focus();
            }
            else
            {
                errorProvider1.SetError(textBox1, "");
            }
        }
    }
}
